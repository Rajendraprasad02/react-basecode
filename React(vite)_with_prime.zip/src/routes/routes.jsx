import CommonChart from "../components/chart/commonChart/CommonChart";

import User from "../pages/user/User";
import Tab from "../components/tabComponent/Tab";
import { Avatar } from "primereact/avatar";
import UserAdd from "../pages/user/UserAdd";
import UserEdit from "../pages/user/UserEdit";
import UserView from "../pages/user/UserView";

import Modalopen from "../pages/modalOpener/Modalopen";

const tabView = [
  {
    func: (options) => {
      return (
        <div
          className="flex align-items-center gap-2 p-3"
          style={{ cursor: "pointer" }}
          onClick={options.onClick}
        >
          <Avatar
            image="https://primefaces.org/cdn/primereact/images/avatar/amyelsner.png"
            shape="circle"
          />
          <span className="font-bold white-space-nowrap">Amy Elsner</span>
        </div>
      );
    },

    element: <p>hi</p>,
  },
  {
    func: (options) => {
      return (
        <div
          className="flex align-items-center gap-2 p-3"
          style={{ cursor: "pointer" }}
          onClick={options.onClick}
        >
          <Avatar
            image="https://primefaces.org/cdn/primereact/images/avatar/amyelsner.png"
            shape="circle"
          />
          <span className="font-bold white-space-nowrap">Test</span>
        </div>
      );
    },

    element: <p>Test</p>,
  },
];

const routes = [
  {
    path: "/user",
    name: "User",
    element: <User />,
  },
  {
    path: "/user/add",
    name: "Add User",
    element: <UserAdd />,
  },
  {
    path: "/user/edit",
    name: "Edit User",
    element: <UserEdit />,
  },
  {
    path: "/user/view",
    name: "Edit User",
    element: <UserView />,
  },

  {
    path: "/dashboard",
    name: "dashboard",
    element: <CommonChart />,
  },
  {
    path: "/tab",
    name: "dashboard",
    element: <Tab tabView={tabView} />,
  },
  {
    path: "/modal",
    name: "modal",
    element: <Modalopen />,
  },
];

export default routes;
