import Search from "../search/CustomSearch";

export default function Menu({ setVisible }) {
  return (
    <div
      style={{
        backgroundColor: "#4D4DFF",
        minHeight: "10%",
        marginBottom: ".5%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <i
        className="pi pi-bars ml-3 text-2xl text-white  lg:hidden"
        onClick={() => setVisible(true)}
      ></i>

      <p className="ml-2 font-semibold text-lg lg:text-2xl text-white ">
        React Framework
      </p>
      <div className="hidden lg:block">
        <Search
          placeholder={"Search..."}
          className={"hidden lg:flex"}
          iconClassName={"text-white"}
        />
      </div>

      <div>
        <i className="pi pi-bell text-lg lg:text-2xl text-white border-circle bg-primary p-1" />
        <i className="pi   pi-user text-lg lg:text-2xl text-white border-circle mx-2 bg-primary p-1" />
      </div>
    </div>
  );
}
