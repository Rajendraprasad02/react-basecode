import { useRef, useState } from "react";
import { Button } from "primereact/button";
import { Ripple } from "primereact/ripple";
import { StyleClass } from "primereact/styleclass";
import logo from "../../assests/images/react.png";
import { useNavigate } from "react-router-dom";
import Menu from "./Menu";

export default function Drawer2({ children }) {
  const navigate = useNavigate();

  const [visible, setVisible] = useState(false);
  const sideBar = [
    {
      div: "FAVORITES",
      li: [
        {
          icon: "pi pi-home",
          name: "Dashboard",
          click: () => {
            navigate("/dashboard");
          },
        },
        {
          icon: "pi pi-chart-line",
          name: "User",
          li: [
            {
              icon: "pi pi-table",
              name: "List View",
              click: () => {
                navigate("/user");
              },
            },
          ],
        },
      ],
    },
  ];

  const [width, setWidth] = useState("2");

  const renderMenuItems = (items) => {
    return items.map((item, index) => {
      const ref = useRef(null);
      const hasChildren = item.li && item.li.length > 0;

      return (
        <li key={index} className="p-mb-2">
          {hasChildren ? (
            <>
              <StyleClass
                nodeRef={ref}
                selector="@next"
                enterClassName="hidden"
                enterActiveClassName="slidedown"
                leaveToClassName="hidden"
                leaveActiveClassName="slideup"
              >
                <a
                  ref={ref}
                  className="p-ripple flex align-items-center cursor-pointer p-3 border-round text-700 hover:surface-100 transition-duration-150 transition-colors w-full"
                  style={width === "2" ? {} : { justifyContent: "center" }}
                >
                  <i
                    className={`${item.icon} text-white `}
                    style={width === "2" ? {} : { fontSize: "30px" }}
                  ></i>
                  {width === "2" && (
                    <span
                      style={{ color: "white" }}
                      className="font-medium ml-3"
                    >
                      {item.name}
                    </span>
                  )}
                  <i
                    style={{ color: "white" }}
                    className={
                      width !== "2"
                        ? "pi pi-chevron-down"
                        : "pi pi-chevron-down ml-auto"
                    }
                  ></i>
                  <Ripple />
                </a>
              </StyleClass>
              <ul className="list-none py-0 pl-3 pr-0 m-0 hidden overflow-y-hidden transition-all transition-duration-400 transition-ease-in-out">
                {renderMenuItems(item.li)}
              </ul>
            </>
          ) : (
            <a
              onClick={item.click}
              className="p-ripple flex align-items-center cursor-pointer p-3 border-round text-700 hover:surface-100 transition-duration-150 transition-colors w-full"
              style={width === "2" ? {} : { justifyContent: "center" }}
            >
              <i
                className={`${item.icon} text-white mr-3`}
                style={width === "2" ? {} : { fontSize: "30px" }}
              ></i>
              {width === "2" && (
                <span className="font-medium" style={{ color: "white" }}>
                  {item.name}
                </span>
              )}
              <Ripple />
            </a>
          )}
        </li>
      );
    });
  };

  return (
    <>
      <div className="grid min-h-screen">
        <div className={` hidden lg:flex lg:col-${width} p-0`}>
          <div
            id="app-sidebar-2"
            className="surface-section h-screen block flex-shrink-0 absolute lg:static left-0 top-0 z-1 border-right-1 surface-border select-none"
            style={{ width: "100%" }}
          >
            <div
              className="flex flex-column h-full"
              style={{ backgroundColor: "#2000C2" }}
            >
              <div className="flex align-items-center justify-content-between px-4 pt-3 flex-shrink-0">
                <span className="flex align-items-center justify-content-center ">
                  <img src={logo} width={"50%"} alt="logo" />
                </span>
                <span>
                  <Button
                    type="button"
                    icon={
                      width === "2"
                        ? "pi pi-chevron-left "
                        : "pi pi-chevron-right"
                    }
                    style={{ color: "white" }}
                    rounded
                    outlined
                    className="h-2rem w-2rem"
                    onClick={() =>
                      setWidth((prev) => (prev === "2" ? "1" : "2"))
                    }
                  ></Button>
                </span>
              </div>
              <div className="overflow-y-none">
                {sideBar.map((elem, index) => {
                  const sectionRef = useRef(null);
                  return (
                    <ul key={index} className="list-none p-2 m-0">
                      <li>
                        <StyleClass
                          nodeRef={sectionRef}
                          selector="@next"
                          enterClassName="hidden"
                          enterActiveClassName="slidedown"
                          leaveToClassName="hidden"
                          leaveActiveClassName="slideup"
                        >
                          <div
                            ref={sectionRef}
                            className="p-ripple p-3 flex align-items-center justify-content-between text-600 cursor-pointer"
                          >
                            <span className="font-medium text-white">
                              {elem.div}
                            </span>
                            <i className="pi pi-chevron-down text-white"></i>
                            <Ripple />
                          </div>
                        </StyleClass>
                        <ul className="list-none p-0 m-0 overflow-hidden">
                          {renderMenuItems(elem.li)}
                        </ul>
                      </li>
                    </ul>
                  );
                })}
              </div>
              <div className="mt-auto">
                <hr className="mb-3 mx-3 border-top-1 border-none surface-border" />
                <a
                  className="m-3 flex align-items-center cursor-pointer p-3 gap-2 border-round text-700 text-white font-semibold text-2xl transition-duration-150 transition-colors p-ripple"
                  style={{ justifyContent: "center" }}
                  onClick={() => {}}
                >
                  Logout
                </a>
              </div>
            </div>
          </div>
        </div>
        <div
          style={{ flexDirection: "column", overflow: "hidden" }}
          className={`col-12 lg:col-${width === "2" ? "10" : "11"} p-0`}
        >
          <div className="">
            <Menu setVisible={setVisible} />
          </div>

          <main style={{ marginLeft: "1%", marginRight: "1%" }}>
            {children}
          </main>
        </div>

        <div
          style={{
            display: visible ? "flex" : "none",
            justifyContent: "center",
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%,-50%)",
            zIndex: "1000",
          }}
          className="lg:hidden"
        >
          <div
            className="flex flex-column h-full"
            style={{ backgroundColor: "#2000C2" }}
          >
            <div className="flex align-items-center justify-content-between px-4 pt-3 flex-shrink-0">
              <span className="flex align-items-center justify-content-center ">
                <img src={logo} width={"50%"} alt="logo" />
              </span>
              <span>
                <Button
                  type="button"
                  icon={"pi pi-times"}
                  style={{ color: "white" }}
                  rounded
                  outlined
                  className="h-2rem w-2rem"
                  onClick={() => setVisible(false)}
                ></Button>
              </span>
            </div>
            <div className="overflow-y-none">
              {sideBar.map((elem, index) => {
                const sectionRef = useRef(null);
                return (
                  <ul key={index} className="list-none p-2 m-0">
                    <li>
                      <StyleClass
                        nodeRef={sectionRef}
                        selector="@next"
                        enterClassName="hidden"
                        enterActiveClassName="slidedown"
                        leaveToClassName="hidden"
                        leaveActiveClassName="slideup"
                      >
                        <div
                          ref={sectionRef}
                          className="p-ripple p-3 flex align-items-center justify-content-between text-600 cursor-pointer"
                        >
                          <span className="font-medium text-white">
                            {elem.div}
                          </span>
                          <i className="pi pi-chevron-down text-white"></i>
                          <Ripple />
                        </div>
                      </StyleClass>
                      <ul className="list-none p-0 m-0 overflow-hidden">
                        {renderMenuItems(elem.li)}
                      </ul>
                    </li>
                  </ul>
                );
              })}
            </div>
            <div className="mt-auto">
              <hr className="mb-3 mx-3 border-top-1 border-none surface-border" />
              <a
                className="m-3 flex align-items-center cursor-pointer p-3 gap-2 border-round text-700 text-white font-semibold text-2xl transition-duration-150 transition-colors p-ripple"
                style={{ justifyContent: "center" }}
                onClick={() => {}}
              >
                Logout
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
