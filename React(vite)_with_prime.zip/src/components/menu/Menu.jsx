import { Menu } from "primereact/menu";
import PropTypes from "prop-types";

export default function BasicMenu({ items }) {
  return (
    <>
      <Menu model={items} />
    </>
  );
}

BasicMenu.proptypes = {
  items: PropTypes.array.isRequired,
};
