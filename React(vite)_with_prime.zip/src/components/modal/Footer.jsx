import Button from "../button/Button";

export default function Footer({ handleClose }) {
  return (
    <div style={{ display: "flex", justifyContent: "end" }}>
      <Button
        name={"Close"}
        style={{ backgroundColor: "red" }}
        onClick={handleClose}
      />
    </div>
  );
}
