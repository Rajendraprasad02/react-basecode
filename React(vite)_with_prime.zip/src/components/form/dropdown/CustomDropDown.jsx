import styles from "./styles.module.css";
import PropTypes from "prop-types";

export default function CustomDropdown({
  id,
  name,
  defaultValue,
  style,
  className,
  labelText,
  labelStyle,
  labelClassName,
  placeholder = "Select an option",
  options = ["New York", "Rome", "London", "Istanbul", "Paris"],
  register,
  required,
  validation,
  disabled,
}) {
  return (
    <>
      <label
        htmlFor={id}
        style={labelStyle}
        className={`block  ${labelClassName}`}
      >
        {labelText}
      </label>
      <select
        className={`${styles.select} ${className}`}
        style={{ width: "70%", ...style }}
        name={name}
        id={id}
        defaultValue={defaultValue}
        aria-labelledby={id}
        {...register(
          name,
          required && {
            required: required,
            validate: validation,
          }
        )}
        disabled={disabled}
      >
        <option value={""}>{placeholder}</option>
        {options?.map((elem, index) => {
          return (
            <option className={styles.options} key={index}>
              {elem}
            </option>
          );
        })}
      </select>
    </>
  );
}

CustomDropdown.propTypes = {
  className: PropTypes.string,
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  defaultValue: PropTypes.string,
  labelText: PropTypes.string,
  labelStyle: PropTypes.object,
  labelClassName: PropTypes.string,
  register: PropTypes.func.isRequired,
  required: PropTypes.string,
  validation: PropTypes.func,
  style: PropTypes.object,
  placeholder: PropTypes.string,
  options: PropTypes.array.isRequired,
};
