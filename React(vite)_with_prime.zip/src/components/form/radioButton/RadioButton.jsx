import styles from "./styles.module.css";
import PropTypes from "prop-types";

export default function CustomRadioButton({
  id,
  name,
  labelText = "Label",
  labelStyle,
  labelClassName,
  radioLabelClassName,
  radioLabelStyle,
  radioList = ["Option 1", "Option 2", "Option 3"],
  wrapperClass,
  wrapperStyle,
  register,
  required,
  validation,
  disabled,
  defaultValue,
}) {
  return (
    <>
      <label
        htmlFor={id}
        style={labelStyle}
        className={`${styles.label} ${labelClassName}`}
      >
        {labelText}
      </label>
      <div className="grid">
        {radioList?.map((category, index) => {
          return (
            <div
              key={index}
              style={wrapperStyle}
              className={`col-12 md:col-6 lg:col-4 flex align-items-end ${styles.checkBoxWrapper} ${wrapperClass}`}
            >
              <input
                autoComplete="off"
                id={id}
                name={name}
                type="radio"
                {...register(
                  name,
                  required && {
                    required: required,
                    validate: validation,
                  }
                )}
                value={category}
                style={{ width: "20px", height: "20px" }}
                disabled={disabled}
                defaultChecked={category === defaultValue}
              />
              <label
                htmlFor={id}
                className={`${radioLabelClassName} ${styles.checkBoxLabel}`}
                style={radioLabelStyle}
              >
                {category}
              </label>
            </div>
          );
        })}
      </div>
    </>
  );
}

CustomRadioButton.propTypes = {
  className: PropTypes.string,
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  defaultValue: PropTypes.string,
  labelText: PropTypes.string,
  labelStyle: PropTypes.object,
  labelClassName: PropTypes.string,
  radioLabelClassName: PropTypes.string,
  radioLabelStyle: PropTypes.object,
  radioList: PropTypes.array.isRequired,
  wrapperClass: PropTypes.string,
  wrapperStyle: PropTypes.object,
  register: PropTypes.func.isRequired,
  required: PropTypes.string,
  validation: PropTypes.func,
  style: PropTypes.object,
};
