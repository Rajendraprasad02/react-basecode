import { TabView, TabPanel } from "primereact/tabview";
import PropTypes from "prop-types";
export default function Tab({ tabView }) {
  return (
    <div className="card">
      <TabView>
        {tabView?.map((elem, index) => (
          <TabPanel key={index} headerTemplate={elem.func}>
            {elem.element}
          </TabPanel>
        ))}
      </TabView>
    </div>
  );
}

Tab.propTypes = {
  tabView: PropTypes.arrayOf(
    PropTypes.objectOf(PropTypes.func, PropTypes.element)
  ),
};
