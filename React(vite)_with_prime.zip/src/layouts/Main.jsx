import { Outlet } from "react-router-dom";

import RouterDemo from "../components/breadcrumbs/BreadCrumb";
import InfinityLoader from "../components/loader/Infinity";
import { useSelector } from "react-redux";

import CustomDrawer from "../components/drawer/CustomDrawer";
import Drawer2 from "../components/drawer/Drawer2";

export default function Main() {
  const selector = useSelector((select) => select.user);

  return (
    <>
      <Drawer2>
        <RouterDemo />
        <Outlet />
      </Drawer2>
      {selector?.status === "loading" && <InfinityLoader />}
    </>
  );
}
