export default function formData(id, col1) {
  return {
    id,
    col1,
  };
}
