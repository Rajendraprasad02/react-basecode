export const userMockData = new Promise((resolve) =>
  setTimeout(
    () =>
      resolve([
        {
          id: 1,
          firstName: 'Jane',
          lastName: 'Doe',
          middleName: 'Baker',
          gender: 'Female',
          phoneNumber: '63+ 932-555-4247',
          email: 'janedoe@gmail.com',
          password: 'Login123'
        },
        {
          id: 2,
          firstName: 'John',
          lastName: 'Smith',
          middleName: 'Alan',
          gender: 'Male',
          phoneNumber: '63+ 932-555-4248',
          email: 'johnsmith@gmail.com',
          password: 'Password123'
        },
        {
          id: 3,
          firstName: 'Alice',
          lastName: 'Johnson',
          middleName: 'Marie',
          gender: 'Female',
          phoneNumber: '63+ 932-555-4249',
          email: 'alicejohnson@gmail.com',
          password: 'Pass1234'
        },
        {
          id: 4,
          firstName: 'Robert',
          lastName: 'Brown',
          middleName: 'William',
          gender: 'Male',
          phoneNumber: '63+ 932-555-4250',
          email: 'robertbrown@gmail.com',
          password: 'Rob1234'
        },
        {
          id: 5,
          firstName: 'Emily',
          lastName: 'Davis',
          middleName: 'Rose',
          gender: 'Female',
          phoneNumber: '63+ 932-555-4251',
          email: 'emilydavis@gmail.com',
          password: 'Em123456'
        },
        {
          id: 6,
          firstName: 'Michael',
          lastName: 'Wilson',
          middleName: 'David',
          gender: 'Male',
          phoneNumber: '63+ 932-555-4252',
          email: 'michaelwilson@gmail.com',
          password: 'Mike1234'
        },
        {
          id: 7,
          firstName: 'Sophia',
          lastName: 'Taylor',
          middleName: 'Anne',
          gender: 'Female',
          phoneNumber: '63+ 932-555-4253',
          email: 'sophiataylor@gmail.com',
          password: 'Sophia123'
        },
        {
          id: 8,
          firstName: 'Daniel',
          lastName: 'Moore',
          middleName: 'Lee',
          gender: 'Male',
          phoneNumber: '63+ 932-555-4254',
          email: 'danielmoore@gmail.com',
          password: 'Dan12345'
        },
        {
          id: 9,
          firstName: 'Olivia',
          lastName: 'Anderson',
          middleName: 'Grace',
          gender: 'Female',
          phoneNumber: '63+ 932-555-4255',
          email: 'oliviaanderson@gmail.com',
          password: 'Olivia123'
        }
      ]),
    1000
  )
);
