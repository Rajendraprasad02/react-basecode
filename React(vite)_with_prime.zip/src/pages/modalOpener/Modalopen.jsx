import { useState } from "react";
import Button from "../../components/button/Button";
import CustomModal from "../../components/modal/CustomModal";

export default function Modalopen() {
  const [visible, setVisible] = useState(false);

  return (
    <div className="card flex justify-content-center">
      <Button
        name={visible ? "Close" : "Show"}
        icon={{ BorAname: "b", iconName: "pi pi-external-link" }}
        style={{ backgroundColor: visible ? "red" : "" }}
        onClick={() => setVisible(!visible)}
      />
      <CustomModal visible={visible} setVisible={setVisible} />
    </div>
  );
}
