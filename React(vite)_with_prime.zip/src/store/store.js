import { configureStore } from "@reduxjs/toolkit";

import userReducer from "../pages/user/userSlice";
import loginReducer from "../pages/login/loginSlice";

export default configureStore({
  reducer: {
    user: userReducer,
    login: loginReducer,
  },
});
