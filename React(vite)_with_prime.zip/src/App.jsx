import { RouterProvider, createBrowserRouter } from "react-router-dom";
import LoginPage from "./pages/login/Login";
import Main from "./layouts/Main";
import routes from "./routes/routes";
import "primeicons/primeicons.css";
import "primereact/resources/themes/lara-light-cyan/theme.css";
import "/node_modules/primeflex/primeflex.css";
import ForgotPassword from "./pages/forgotPassword/ForgotPassword";
import Registration from "./pages/registerForm/RegistrationForm";
import Profile from "./pages/profile/Profile";
import ErrorPage from "./pages/errorPage/ErrorPage";

const router = createBrowserRouter([
  {
    path: "/",
    element: <LoginPage />,
  },
  {
    path:'/forgot-password',
    element:<ForgotPassword/>
  },
  {
    path:'/register',
    element:<Registration/>
  },
  {
    path:'/profile',
    element:<Profile/>
  },
  {
    path:'/Errorpage',
    element:<ErrorPage/>
  },
  {
    path: "/",
    element: <Main />,
    children: routes,
  },  



]);

export default function App() {
  return <RouterProvider router={router} />;
}
